function enCambioDeOrientacion(){
    
    switch(window.orientation){
        
        case -90:
        case 90:
            $("body").addClass("horizontal").removeClass("vertical");
            break;
        default:
            $("body").addClass("vertical").removeClass("horizontal");
            break;
            
            
    }
    
}

window.addEventListener('orientationchange' , enCambioDeOrientacion );

enCambioDeOrientacion();

function reproducirVideo(){
    
    var objetoVideo = document.getElementById("miVideo");
    objetoVideo.play();
    
}

function detenerVideo(){
    
    var objetoVideo = document.getElementById("miVideo");
    objetoVideo.pause();
    
}

function obtenerUbicacion(){
    
    navigator.geolocation.getCurrentPosition( mostrarUbicacion );
}

function mostrarUbicacion(ubicacion){
    
    alert( "latitud: " +  ubicacion.coords.latitude + " longitud" + ubicacion.coords.longitude )
}