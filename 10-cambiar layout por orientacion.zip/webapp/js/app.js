function enCambioDeOrientacion(){
    
    switch(window.orientation){
        
        case -90:
        case 90:
            $("body").addClass("horizontal").removeClass("vertical");
            break;
        default:
            $("body").addClass("vertical").removeClass("horizontal");
            break;
            
            
    }
    
}

window.addEventListener('orientationchange' , enCambioDeOrientacion );

enCambioDeOrientacion();

